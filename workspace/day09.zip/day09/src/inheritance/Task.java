package inheritance;

class Animals{
	String name;
	String species;
	int age;
	
	public Animals(String name, int age, String species) {
		this.name = name;
		this.species = species;
		this.age = age;
	}

	void printInfo() {
		System.out.println("이름: "+ name);
		System.out.println("나이: "+ age);
		System.out.println("종류: "+ species);
	}
}

class SickAnimal extends Animals{
	String disease;
	
	public SickAnimal(String name, int age, String species, String disease) {
		super(name, age, species);
		this.disease = disease;
	}

	@Override
	void printInfo() {
		super.printInfo();
		System.out.println("병명: " + disease);
	}
	
	void cure() {
		System.out.println(name +" "+ disease + "이(가) 잘 치유되었습니다.");
	}
}

public class Task {
	public static void main(String[] args) {
		SickAnimal sa = new SickAnimal("멍멍이", 1, "포메라니언", "감기");
		sa.printInfo();
		sa.cure();
	}
}
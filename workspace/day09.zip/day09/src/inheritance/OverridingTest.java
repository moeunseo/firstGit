package inheritance;

class Animal{
	String name;
	int age;
	
	void printInfo(){
		System.out.println("이름: " + name);
		System.out.println("나이: " + age);
	}
}

class Dog extends Animal{
	String species;
	
	public Dog(String name, int age, String species) {
		this.name = name;
		this.age = age;
		this.species = species;
	}

	@Override
	void printInfo() {
//		super.printInfo(); //굳이 부모에 있는 메소드를 부르고 싶을 때 사용
		System.out.println("이름: " + name);
		System.out.println("나이: " + age + "살");
		System.out.println("강아지 종: "+ species);
	}
}

public class OverridingTest {
	public static void main(String[] args) {
		Dog dog = new Dog("멍멍이", 1, "포메라니언");
		// 자식에서 재정의해준 메소드가 실행
		dog.printInfo();
	}
}

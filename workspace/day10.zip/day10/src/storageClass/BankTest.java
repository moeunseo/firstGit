package storageClass;

public class BankTest {
	public static void main(String[] args) {
		Bankbook momCard = new Bankbook();
		Bankbook myCard = new Bankbook();
		
		// 전역변수 테스트
		momCard.withdraw(1000);
		momCard.withdraw(1000);
		momCard.withdraw(1000);
		momCard.withdraw(1000);
		momCard.withdraw(1000);
		System.out.println(momCard.money);
		
		momCard = new Bankbook();
		System.out.println("전역 변수: "+ momCard.money);
		
		// 정적변수 테스트
		momCard.withdraw_s(1000);
		momCard.withdraw_s(1000);
		momCard.withdraw_s(1000);
		momCard.withdraw_s(1000);
		momCard.withdraw_s(1000);
		System.out.println("정적 변수: " + momCard.money_s);
		
		momCard = new Bankbook();
		System.out.println("엄마 정적 변수: " + momCard.money_s);
		System.out.println("딸 정적 변수: " + myCard.money_s);
		
		// 컴파일러가 직접 메모리에 올려주기 때문, 프로그램 시작하자마자 올림
		// 객체로 접근할 필요없이, 소속만 알려주면 사용 가능
		System.out.println(Bankbook.money_s);
		
		// static mehtod도 컴파일러가 직접 메모리에 제일 먼저 올려준다.
		// 1. 해당 클래스에 너무 많은 함수가 선언되어 있어 용량이 큼
		// > 전체를 메모리에 올린 후에 하나를 사용하기에는 부담스러울 때, 메소드 하나를 static으로 선언
		// ex) Integer.parseInt();

		// 2. 자주 사용하는 메소드이기에 객체화 없이 사용하기 위해 static으로 선언
	}
}

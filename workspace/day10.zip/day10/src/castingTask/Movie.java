package castingTask;

public class Movie extends OTT{
	void support4D() {
		System.out.println("4D로 영화가 시작됩니다.");
	}
}

package classTest;

// 클래스는 패키지 안에 선언
class Student{ //추상적인 개념 틀
	int number;
	String name;
	int age;
	int kor;
	int eng;
	int math;
	
	// 평균을 구해주는 메소드
	void printAvg() {
		// 앞에 this가 생략된 상태
		System.out.printf("이름: %s\n평균: %.2f\n", name, (kor+eng+math)/3.0);
	}
}

public class ClassTest {
	public static void main(String[] args) {
		// 메모리에 올리는 과정 > 객체화
		// new 는 객체를 메모리에 할당과 동시에 초기화까지 진행
		Student st = new Student(); //객체 생성
		Student st2 = new Student();
		
		// 객체화를 통해 메모리에 할당해줘야지만, 해당 변수로 접근 가능
		System.out.println(st.name);
		System.out.println(st2.name);
		
		// 해당 변수로 접근해서 값의 수정도 가능
		st.name = "모은서";
		st2.name = "이창섭";
		System.out.println(st.name);
		System.out.println(st2.name);
		
		// 국영수 변수 초기화
		st.kor = 100;
		st.eng = 70;
		st.math = 78;
		
		st2.kor = 77;
		st2.eng = 49;
		st2.math = 94;
		
		st.printAvg();
		st2.printAvg();
	}
}

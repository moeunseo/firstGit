package classTest;

class Fruit{
	String name;
	int price;
	String homeTown = "거창"; //값을 고정하고 싶을 때
	
	// 기본생성자
	Fruit(){;}
	
	// 생성자: 무수히 많이 존재할 수 있음
	// 매개변수로 원산지를 전달하지 않을 때 실행
	// this를 사용하지 않고 싶다면 변수명을 다르게 하기
	Fruit(String name, int price){
		// this(변수) : 접근하는 객체의 주소를 가짐
		this.name = name;
		this.price = price;
		this.homeTown = "원산지 입력 필요";
	}
	
	// 초기화 생성자
	public Fruit(String name, int price, String homeTown) {
		this.name = name;
		this.price = price;
		this.homeTown = homeTown;
	}
}

public class ClassTest2 {
	public static void main(String[] args) {
		// 객체 생성 시 , 생성자 실행
		Fruit apple = new Fruit("사과", 5000);
		System.out.println(apple.name);
		System.out.println(apple.price);
		System.out.println(apple.homeTown);
		
		System.out.println("================================");
		
		Fruit orange = new Fruit("오렌지", 9900, "제주도");
		System.out.println(orange.name);
		System.out.println(orange.price);
		System.out.println(orange.homeTown);
	}
}
package ambiguityTest;

public class ClassA {
	public void printName() {
		System.out.println("ClassA");
	}
}

package ambiguityTest;

public class Test2 extends ClassA implements InterA{
	public static void main(String[] args) {
		Test2 t2 = new Test2();
		
		// 부모에 있는 메소드 호출
		t2.printName();
	}
}

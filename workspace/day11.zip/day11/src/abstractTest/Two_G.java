package abstractTest;

public class Two_G extends SellPhone{

	@Override
	public void call() {
		System.out.println("2G 전용 광대역 사용!");
	}

	@Override
	public void sendSMS() {
		System.out.println("2G 문자 전화 공짜 아님!");
	}
	
	public static void main(String[] args) {
		Two_G t = new Two_G();
		
		t.printNum();
		t.call();
		t.sendSMS();
	}
}

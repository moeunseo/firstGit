package abstractTest;

public class Three_G extends SellPhone{
	
	// 강제성을 부여하여 메소드 재정의
	@Override
	public void call() {
		System.out.println("전화받아~~");
		
	}

	@Override
	public void sendSMS() {
		System.out.println("문자받아~~");
		
	}

	public static void main(String[] args) {
		Three_G t = new Three_G();
		
		System.out.println(t.phoneNumber);
		t.printNum();
		t.call();
		t.sendSMS();
	}
}
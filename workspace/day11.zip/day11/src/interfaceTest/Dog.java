package interfaceTest;

public class Dog implements Animal {

	@Override
	public void eat() {
		System.out.println("간식을 냠냠");
	}

	@Override
	public void breath() {
		System.out.println("들숨 날숨");
	}
	
	// body를 만드는 것만으로도 구현한 거라고 판단!
	@Override
	public void bark() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bite() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void waitNow() {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		Dog dog = new Dog();
		
		System.out.println(dog instanceof Animal);
		
		dog.eat();
		dog.breath();
	}

}

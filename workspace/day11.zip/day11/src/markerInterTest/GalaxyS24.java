package markerInterTest;

public class GalaxyS24 extends SamsungStuff implements GalaxyS{

}

package markerInterTest;

public interface GalaxyBook {
}

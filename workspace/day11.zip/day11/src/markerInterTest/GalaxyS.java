package markerInterTest;

public interface GalaxyS {

}

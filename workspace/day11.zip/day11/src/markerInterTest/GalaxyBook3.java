package markerInterTest;

public class GalaxyBook3 extends SamsungStuff implements GalaxyBook{

}

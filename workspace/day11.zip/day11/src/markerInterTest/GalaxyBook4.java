package markerInterTest;

public class GalaxyBook4 extends SamsungStuff implements GalaxyBook{

}

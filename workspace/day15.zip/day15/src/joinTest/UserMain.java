package joinTest;

public class UserMain {
	public static void main(String[] args) {
		new UserController();
	}
}
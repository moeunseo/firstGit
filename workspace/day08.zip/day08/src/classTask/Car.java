package classTask;

public class Car {
	String name;
	int pw;
	int cnt; //비밀번호 입력 시 횟수
	boolean door;
	boolean engine;
	
	Car(String name, int pw){
		this.name = name;
		this.pw = pw;
		System.out.println(this.name + this.pw);
	}
	
	void openDoor(int pw){
		//비밀번호 비교
	}
	
	void engineStart() {
		
	}
	
	void engineStop() {
		
	}
}

package classTask;

import java.util.Scanner;

public class CarMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Car car = null;
		String startMsg = "1. 문 열기  2. 문 닫기  3. 시동켜기 4. 시동끄기 5. 종료";
		String menuMsg = "메뉴 선택 >> "; 
		String carName = null;
		int choice = 0;
		int pw = 0;
		
		// door engine는 false 로 고정!
		System.out.print("자동차 이름을 정해보자 ");
		carName = sc.next();
		System.out.print("비밀번호 입력해줘 ");
		pw = sc.nextInt();
		car = new Car(carName, pw);
		
		while(true) {
			System.out.println(startMsg);
			System.out.println(menuMsg);
			choice = sc.nextInt();
			
			if(choice == 5) {
				System.out.println("프로그램 종료!");
				break;
			}
			
			switch(choice) {
			case 1:
				car.openDoor(pw);
				break;
			case 2:
				car.door = false;
				break;
			case 3:
				car.engineStart();
				break;
			case 4:
				car.engineStop();
				break;
			default:
				System.out.println("번호 다시 입력! [1-5번]");
			}
		}		
	}
}

package objectTest;

import apiTest.Food;

public class ToStringTest {
	public static void main(String[] args) {
		
		Animal js = new Animal(1, "진순이", 1, "진돗개", "3kg");
		
		System.out.println(js.toString());
		
		
	}
}

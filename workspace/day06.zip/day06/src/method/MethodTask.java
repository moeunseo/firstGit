package method;

public class MethodTask {
	// 두 정수의 나눗셈을 해주는 메소드 (몫과 나머지를 둘 다 리턴)
	int[] divide(int num1, int num2) {
		int[] result = new int[2];
		if(num2 == 0) {
			System.out.println("0으로 나눌 수 없습니다.");
			return null; //함수의 종료.
		}
		
		result[0] = num1/num2;
		result[1] = num1%num2;
		
		return result;
	}
	
	void getMinMax(int[] datas, int[] minmax) {
		int max = datas[0];
		int min = datas[0];
		
		for(int i=1;i<datas.length;i++) {
			if(max < datas[i]) {
				max = datas[i];
			}
			
			if(min > datas[i]) {
				min = datas[i];
			}
		}
		minmax[0] = min;
		minmax[1] = max;
		
		
	}
	public static void main(String[] args) {
		MethodTask mt = new MethodTask();
		int[] result = new int[2];
		result = mt.divide(10, 0);
		if(result != null) {
			System.out.println("몫 : " + result[0]);
			System.out.println("나머지 : " + result[1]);
		}
		
		int[] datas = {10, 50, 70, 60, 30};
		int[] minmax = new int[2];
		
		 mt.getMinMax(datas, minmax);
		 
		 System.out.println("최솟값 : " + minmax[0]);
		 System.out.println("최댓값 : " + minmax[1]);

	}
}

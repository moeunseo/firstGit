package method;

import java.util.Scanner;

public class MethodTest2 {
	// 1~n까지의 정수의 합을 리턴해주는 함수
	int getTotal(int num) {
		int sum = 0;
		for(int i=1;i<=num;i++) {
			sum+=i;
		}
		return sum;
	}
	
	int getSum() {
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		System.out.print("n값을 입력하시오 >> ");
		int num = sc.nextInt();
		
		for(int i=1;i<=num;i++) {
			sum+=i;
		}
		return sum;
	}
	
	int getPlus(Scanner sc) {
		int sum = 0;
		System.out.print("n값을 입력하시오 >> ");
		int num = sc.nextInt();
		
		for(int i=1;i<=num;i++) {
			sum+=i;
		}
		return sum;
	}
	
	public static void main(String[] args) {
		MethodTest2 mt = new MethodTest2(); //클래스 안에 정의된 함수들을 쓸거야! 라는 정의
		Scanner sc = new Scanner(System.in);
//		int n = 0;
//		
//		// 1~n까지의 정수의 합을 리턴해주는 테스트
//		System.out.print("n값을 입력하시오 >> ");
//		n = sc.nextInt();
//		System.out.println("총합 : " + mt.getTotal(n));
		
		// 입력받는 것까지 메소드에 포함테스트
		int result = mt.getSum();
		System.out.println(result);
		
		int result2 = mt.getPlus(sc);
		System.out.println(result2);
	}
}
